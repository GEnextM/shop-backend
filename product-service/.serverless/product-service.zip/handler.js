 'use strict';

 import { getproductbyid } from "./handlers/getproductbyid.cjs";
 import { hello } from "./handlers/getproducts.cjs";



