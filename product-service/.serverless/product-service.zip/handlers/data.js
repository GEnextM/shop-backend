'use strict'

exports.productslist = [
    {
      "count": 4,
      "description": "Short Product Description1",
      "id": "1",
      "price": 2.4,
      "img": "https://vberloge.by/upload/iblock/fda/fda55401c6091b76da7e16e7a386dce1.jpg",
      "title": "Кот 'Барсик'"
    },
    {
      "count": 6,
      "description": "Short Product Description3",
      "id": "2",
      "price": 10,
      "img": "https://www.aleshka.by/upload/iblock/527/ikkvi013%20Pink%20Bunny%201.jpg",
      "title": "Вязаная игрушка Кролик"
    },
    {
      "count": 7,
      "description": "Short Product Description2",
      "id": "3",
      "price": 23,
      "img": "https://www.aleshka.by/upload/iblock/c98/9eozcdfezm65zd3u1y0lc5hqj2ey8s8f/0.jpg",
      "title": "Интерактивная игрушка Star Wars Малыш Мандалорец"
    },
    {
      "count": 12,
      "description": "Short Product Description7",
      "id": "4",
      "price": 15,
      "img": "https://www.aleshka.by/upload/iblock/174/%D0%91%D0%B5%D0%B7-%D0%B8%D0%BC%D0%B5%D0%BD%D0%B8-1.jpg",
      "title": "Игрушка мягкая музыкальная Говорящий Щенок"
    },
    {
      "count": 7,
      "description": "Short Product Description2",
      "id": "5",
      "price": 23,
      "img": "https://www.aleshka.by/upload/iblock/985/0.jpg",
      "title": "Игрушка мягкая Медвежонок"
    },
    {
      "count": 8,
      "description": "Short Product Description4",
      "id": "6",
      "price": 15,
      "img": "https://www.aleshka.by/upload/iblock/dd7/%D0%91%D0%B5%D0%B7-%D0%B8%D0%BC%D0%B5%D0%BD%D0%B8-1-%D0%B2%D0%BE%D1%81%D1%81%D1%82%D0%B0%D0%BD%D0%BE%D0%B2%D0%BB%D0%B5%D0%BD%D0%BE.jpg",
      "title": "Игрушка мягконабивная Русалка Anastasia"
    },
    {
      "count": 2,
      "description": "Short Product Descriptio1",
      "id": "7",
      "price": 23,
      "img": "https://www.aleshka.by/upload/iblock/e3f/%D0%91%D0%B5%D0%B7-%D0%B8%D0%BC%D0%B5%D0%BD%D0%B8-1.jpg",
      "title": "Игрушка мягконабивная Принцесса Anna"
    },
    {
      "count": 3,
      "description": "Short Product Description7",
      "id": "8",
      "price": 15,
      "img": "https://www.aleshka.by/upload/iblock/797/%D0%91%D0%B5%D0%B7-%D0%B8%D0%BC%D0%B5%D0%BD%D0%B8-14.jpg",
      "title": "Игрушка мягкая Петушок"
    }
  ]


